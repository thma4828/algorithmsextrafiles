#include <iostream>

using namespace std;

int main(){
    int item1 = 5;
    int item2 = 7;
    int item3 = 8;
    item *x = new item(item1);
    item *x1 = new item(item2);
    item *x2 = new item(item3);
    x->next = x1;
    x1->next
}
