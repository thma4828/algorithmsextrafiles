#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>


using namespace std;

int main(){

    return 0;
}

