#include <iostream>
#include <string>

using namespace std;

int main(){
    string t1 = "New York";
    string t2 = "New York";

    if(t1 == t2)
        cout << "MATCH FOUND" << endl;

    return 0;

}
