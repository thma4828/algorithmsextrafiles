//testdoc
#include <string>
#include <iostream>

using namespace std;

int main(){
    string t = "5";
    string x = stoi(t);
    string tt = stoi(5);

}
